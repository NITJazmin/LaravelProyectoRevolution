@extends('layouts.admin')
@section('contenido')

<h3>En construccion</h3>
@endsection