@extends('layouts.empresa')
@section('contenido')

<h3>Contenido de empresas</h3>
@endsection